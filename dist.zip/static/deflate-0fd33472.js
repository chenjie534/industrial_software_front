import{i as r}from"./pako.esm-72550124.js";import{B as a}from"./basedecoder-3573ccae.js";class s extends a{decodeBlock(e){return r(new Uint8Array(e)).buffer}}export{s as default};
