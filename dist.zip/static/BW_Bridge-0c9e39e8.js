const r=""+new URL("BW_Bridge-9223918c.png",import.meta.url).href;export{r as _};
