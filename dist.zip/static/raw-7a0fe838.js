import{B as o}from"./basedecoder-3573ccae.js";class d extends o{decodeBlock(e){return e}}export{d as default};
